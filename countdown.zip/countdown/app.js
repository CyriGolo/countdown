let minI = document.querySelector('#min')
let secI = document.querySelector('#sec')
let min
let sec
let interval
let pOrR = false
let start = document.querySelector('#start')
let pause = document.querySelector('#pause')
let reset = document.querySelector('#reset')
let cdn = document.querySelector('p')

start.addEventListener("click", ()=>{
    min = parseInt(minI.value);
    sec = parseInt(secI.value) + 1;
    start.disabled = true;
    pause.disabled = false;
    reset.disabled = false;
    cdn.textContent = minI.value + ":" + secI.value;
    startCD()
});

pause.addEventListener("click", ()=>{
    if (pOrR == false) {
        document.querySelector("i").className = "fa fa-caret-right";
        pOrR = true;
        sec++
    } else {
        document.querySelector("i").className = "fa fa-pause";
        pOrR = false
        startCD()
    }
    
});


reset.addEventListener("click", ()=>{
    if (confirm('Are you sure you want to reset the countdown ?')) {
        cdn.textContent = "WAIT..."
        clearInterval(interval);
        start.disabled = false;
        pause.disabled = true;
        reset.disabled = true;
    }
});


function startCD() {
    interval = setInterval(function(){
        sec--
        if(min != 0 && sec < 0) {
            min--
            sec += 60;
        }

        if(min < 10 && sec < 10) {
            cdn.textContent = "0" + min + ":" + "0" + sec;
        } else if (min < 10 && sec > 9) {
            cdn.textContent = "0" + min + ":" + sec;
        } else if (min > 9 && sec < 10) {
            cdn.textContent = min + ":" + "0" + sec;
        } else {
            cdn.textContent = min + ":" + sec;
        }
        if(min == 0 && sec == 0 || pOrR == true) {clearInterval(interval);}
    }, 1000)
}


